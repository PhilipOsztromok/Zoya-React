const config = {
    PORT: 5000,
    CORS_ORIGIN: "http://localhost:5173"
    };
    
    export default config;